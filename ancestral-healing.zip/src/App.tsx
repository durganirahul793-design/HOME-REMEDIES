import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  MapPin, 
  Leaf, 
  Sparkles, 
  X, 
  ChevronRight, 
  BookOpen, 
  Heart,
  MessageSquare,
  ArrowRight,
  AlertCircle
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { Remedy, UserLocation, Region } from './types';
import { MOCK_REMEDIES } from './data';
import { RemedyCard } from './components/RemedyCard';
import { getAncestralAdvice, explainRemedy } from './services/gemini';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [location, setLocation] = useState<UserLocation | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRemedy, setSelectedRemedy] = useState<Remedy | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [remedyExplanation, setRemedyExplanation] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'local' | 'symptoms'>('all');

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(async (position) => {
        const { latitude, longitude } = position.coords;
        
        // In a real app, we'd reverse geocode here. 
        // For now, we'll simulate finding the region.
        // Let's assume Asia for demo purposes if we can't geocode.
        setLocation({
          latitude,
          longitude,
          city: "Detecting...",
          country: "Detecting...",
          region: "Asia" // Default for demo
        });

        try {
          const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`);
          const data = await response.json();
          const country = data.address.country;
          
          // Simple mapping for demo
          let region: Region = 'Global';
          if (['India', 'China', 'Japan', 'Thailand', 'Vietnam'].includes(country)) region = 'Asia';
          else if (['USA', 'Canada', 'Mexico', 'Brazil'].includes(country)) region = 'Americas';
          else if (['UK', 'France', 'Germany', 'Italy', 'Spain'].includes(country)) region = 'Europe';
          else if (['Nigeria', 'Egypt', 'South Africa', 'Kenya'].includes(country)) region = 'Africa';

          setLocation(prev => ({
            ...prev!,
            city: data.address.city || data.address.town || data.address.village,
            country: country,
            region: region
          }));
        } catch (e) {
          console.error("Geocoding failed", e);
        }
      });
    }
  }, []);

  const filteredRemedies = useMemo(() => {
    let results = MOCK_REMEDIES;

    if (activeTab === 'local' && location?.region) {
      results = results.filter(r => r.region === location.region || r.region === 'Global');
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      results = results.filter(r => 
        r.name.toLowerCase().includes(query) ||
        r.symptoms.some(s => s.toLowerCase().includes(query)) ||
        r.illness.some(i => i.toLowerCase().includes(query)) ||
        r.ingredients.some(i => i.toLowerCase().includes(query))
      );
    }

    return results;
  }, [searchQuery, activeTab, location]);

  const handleAskAi = async () => {
    if (!searchQuery) return;
    setIsAiLoading(true);
    setAiAdvice(null);
    const advice = await getAncestralAdvice(searchQuery, location?.city);
    setAiAdvice(advice);
    setIsAiLoading(false);
  };

  const handleRemedyClick = async (remedy: Remedy) => {
    setSelectedRemedy(remedy);
    setRemedyExplanation(null);
    setIsAiLoading(true);
    const explanation = await explainRemedy(remedy);
    setRemedyExplanation(explanation);
    setIsAiLoading(false);
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Hero Section */}
      <header className="px-6 pt-12 pb-8 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 mb-4"
        >
          <div className="w-10 h-10 rounded-full bg-brand-olive flex items-center justify-center text-white">
            <Leaf className="w-6 h-6" />
          </div>
          <h1 className="text-3xl font-serif font-bold tracking-tight">Ancestral Healing</h1>
        </motion.div>
        
        <p className="text-lg text-brand-ink/70 font-serif italic mb-8">
          "The wisdom of our elders, preserved for the modern traveler."
        </p>

        {/* Location Banner */}
        {location && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white/50 backdrop-blur-sm border border-brand-olive/20 rounded-2xl p-4 mb-8 flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-brand-olive/10 rounded-full">
                <MapPin className="w-5 h-5 text-brand-olive" />
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-widest font-bold text-brand-olive/60">Current Location</p>
                <p className="font-medium">{location.city}, {location.country}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-widest font-bold text-brand-olive/60">Cultural Region</p>
              <p className="font-medium">{location.region}</p>
            </div>
          </motion.div>
        )}

        {/* Search Bar */}
        <div className="relative mb-8">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-brand-ink/30" />
          </div>
          <input
            type="text"
            placeholder="Search symptoms, illness, or ingredients..."
            className="w-full bg-white border border-black/5 rounded-2xl py-4 pl-12 pr-32 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-olive/20 transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAskAi()}
          />
          <button 
            onClick={handleAskAi}
            disabled={!searchQuery || isAiLoading}
            className="absolute right-2 top-2 bottom-2 px-4 bg-brand-olive text-white rounded-xl text-sm font-medium hover:bg-brand-olive/90 transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            {isAiLoading ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}
            Ask AI
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 border-b border-black/5 mb-8">
          {[
            { id: 'all', label: 'All Remedies', icon: BookOpen },
            { id: 'local', label: 'Local Wisdom', icon: MapPin },
            { id: 'symptoms', label: 'By Symptom', icon: Heart },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "pb-4 px-2 text-sm font-medium transition-all relative flex items-center gap-2",
                activeTab === tab.id ? "text-brand-olive underline underline-offset-8" : "text-brand-ink/40 hover:text-brand-ink/60"
              )}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Symptom Cloud */}
        {activeTab === 'symptoms' && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-wrap gap-2 mb-8"
          >
            {[
              "Cough", "Fever", "Pain", "Skin", "Stomach", "Inflammation", "Burn", "Congestion", "Nausea"
            ].map((s) => (
              <button
                key={s}
                onClick={() => setSearchQuery(s)}
                className={cn(
                  "text-xs px-4 py-2 rounded-full border transition-all",
                  searchQuery.toLowerCase() === s.toLowerCase() 
                    ? "bg-brand-olive text-white border-brand-olive" 
                    : "bg-white border-black/5 text-brand-ink/60 hover:border-brand-olive/20"
                )}
              >
                {s}
              </button>
            ))}
          </motion.div>
        )}

        {/* Suggested Questions */}
        {!searchQuery && !aiAdvice && activeTab !== 'symptoms' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-wrap gap-2 mb-8"
          >
            <span className="text-[10px] uppercase tracking-widest font-bold text-brand-ink/30 py-2 mr-2">Try asking:</span>
            {[
              "Remedies for a persistent dry cough",
              "How to treat a minor burn naturally?",
              "Traditional ways to improve sleep",
              "Natural relief for joint pain"
            ].map((q) => (
              <button
                key={q}
                onClick={() => {setSearchQuery(q); handleAskAi();}}
                className="text-xs bg-white border border-black/5 px-3 py-1.5 rounded-full hover:bg-brand-olive/5 hover:border-brand-olive/20 transition-all text-brand-ink/60"
              >
                {q}
              </button>
            ))}
          </motion.div>
        )}
      </header>

      {/* Main Content */}
      <main className="px-6 max-w-4xl mx-auto">
        {/* AI Advice Section */}
        <AnimatePresence>
          {aiAdvice && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 'auto', height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-12 overflow-hidden"
            >
              <div className="bg-brand-olive/5 border border-brand-olive/20 rounded-3xl p-8 relative">
                <div className="absolute top-4 right-4">
                  <button onClick={() => {setAiAdvice(null); setSearchQuery('');}} className="p-1 hover:bg-brand-olive/10 rounded-full transition-colors">
                    <X className="w-5 h-5 text-brand-olive/40" />
                  </button>
                </div>
                <div className="flex items-center gap-2 mb-6 text-brand-olive">
                  <MessageSquare className="w-5 h-5" />
                  <h2 className="text-xl font-serif font-bold">The Ancestors Speak</h2>
                </div>
                <div className="markdown-body text-brand-ink/80">
                  <ReactMarkdown>{aiAdvice}</ReactMarkdown>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Remedy Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredRemedies.map((remedy) => (
            <RemedyCard 
              key={remedy.id} 
              remedy={remedy} 
              onClick={handleRemedyClick} 
            />
          ))}
        </div>

        {filteredRemedies.length === 0 && (
          <div className="text-center py-20 bg-white/30 rounded-[40px] border border-dashed border-black/10">
            <div className="w-16 h-16 bg-brand-cream rounded-full flex items-center justify-center mx-auto mb-6">
              <BookOpen className="w-8 h-8 text-brand-ink/20" />
            </div>
            <h3 className="text-xl font-serif font-bold mb-2">No local remedies found</h3>
            <p className="text-brand-ink/40 italic max-w-xs mx-auto mb-8">
              {activeTab === 'local' 
                ? `We don't have specific remedies for ${location?.region} yet, but you can explore our global collection.`
                : "No remedies match your current search criteria."}
            </p>
            <button 
              onClick={() => {setSearchQuery(''); setActiveTab('all');}}
              className="px-6 py-2 bg-brand-olive text-white rounded-xl text-sm font-medium hover:bg-brand-olive/90 transition-colors"
            >
              View All Remedies
            </button>
          </div>
        )}
      </main>

      {/* Remedy Detail Modal */}
      <AnimatePresence>
        {selectedRemedy && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedRemedy(null)}
              className="absolute inset-0 bg-brand-ink/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-2xl bg-brand-cream rounded-[40px] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="absolute top-6 right-6 z-10">
                <button 
                  onClick={() => setSelectedRemedy(null)}
                  className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-gray-50 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="overflow-y-auto p-8 md:p-12">
                <div className="flex flex-col md:flex-row gap-8 mb-12">
                  <div className="w-full md:w-48 h-64 rounded-full overflow-hidden border-4 border-white shadow-xl shrink-0">
                    <img 
                      src={`https://picsum.photos/seed/${selectedRemedy.imageSeed}/400/600`} 
                      alt={selectedRemedy.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex-1">
                    <span className="text-xs uppercase tracking-[0.2em] font-bold text-brand-olive mb-4 block">
                      {selectedRemedy.region} • {selectedRemedy.culturalOrigin}
                    </span>
                    <h2 className="text-4xl md:text-5xl font-serif font-bold leading-tight mb-6">
                      {selectedRemedy.name}
                    </h2>
                    <div className="flex flex-wrap gap-2">
                      {selectedRemedy.symptoms.map(s => (
                        <span key={s} className="px-3 py-1 bg-white border border-black/5 rounded-full text-xs font-medium">
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-12">
                  <div>
                    <h3 className="text-lg font-serif font-bold mb-4 flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-brand-olive" />
                      Ingredients
                    </h3>
                    <ul className="space-y-2">
                      {selectedRemedy.ingredients.map((ing, i) => (
                        <li key={i} className="flex items-center gap-3 text-brand-ink/80">
                          <ChevronRight className="w-4 h-4 text-brand-olive/40" />
                          {ing}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-lg font-serif font-bold mb-4 flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-brand-olive" />
                      Preparation
                    </h3>
                    <p className="text-brand-ink/80 leading-relaxed italic">
                      {selectedRemedy.preparation}
                    </p>
                  </div>
                </div>

                {selectedRemedy.caution && (
                  <div className="mb-12 p-4 bg-red-50 border border-red-100 rounded-2xl flex gap-4">
                    <AlertCircle className="w-6 h-6 text-red-500 shrink-0" />
                    <div>
                      <h4 className="font-bold text-red-900 text-sm mb-1">Caution</h4>
                      <p className="text-red-800 text-sm leading-relaxed">{selectedRemedy.caution}</p>
                    </div>
                  </div>
                )}

                <div className="border-t border-black/5 pt-12">
                  <div className="flex items-center gap-2 mb-6 text-brand-olive">
                    <Sparkles className="w-5 h-5" />
                    <h3 className="text-xl font-serif font-bold">Ancestral & Scientific Context</h3>
                  </div>
                  
                  {isAiLoading && !remedyExplanation ? (
                    <div className="flex flex-col items-center py-12 gap-4">
                      <div className="w-8 h-8 border-4 border-brand-olive/20 border-t-brand-olive rounded-full animate-spin" />
                      <p className="text-sm text-brand-ink/40 italic">Consulting the archives...</p>
                    </div>
                  ) : (
                    <div className="markdown-body text-brand-ink/70">
                      <ReactMarkdown>{remedyExplanation || selectedRemedy.scientificContext || ""}</ReactMarkdown>
                    </div>
                  )}
                </div>
              </div>

              <div className="p-6 bg-white/50 border-t border-black/5 flex justify-center">
                <button 
                  onClick={() => setSelectedRemedy(null)}
                  className="px-8 py-3 bg-brand-ink text-white rounded-2xl font-medium hover:bg-brand-ink/90 transition-colors flex items-center gap-2"
                >
                  Close Archive <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Footer / Disclaimer */}
      <footer className="mt-20 px-6 py-12 border-t border-black/5 max-w-4xl mx-auto text-center">
        <p className="text-[10px] uppercase tracking-[0.3em] font-bold text-brand-ink/30 mb-4">
          Ancestral Healing Repository
        </p>
        <p className="text-xs text-brand-ink/40 leading-relaxed max-w-lg mx-auto">
          Disclaimer: This application provides information about traditional home remedies for educational purposes only. It is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition.
        </p>
      </footer>
    </div>
  );
}
