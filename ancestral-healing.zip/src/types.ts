export type Region = 'Asia' | 'Africa' | 'Europe' | 'Americas' | 'Oceania' | 'Global';

export interface Remedy {
  id: string;
  name: string;
  symptoms: string[];
  illness: string[];
  ingredients: string[];
  preparation: string;
  culturalOrigin: string;
  region: Region;
  scientificContext?: string;
  caution?: string;
  imageSeed: string;
}

export interface UserLocation {
  latitude: number;
  longitude: number;
  city?: string;
  country?: string;
  region?: Region;
}
