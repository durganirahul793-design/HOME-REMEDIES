import React from 'react';
import { motion } from 'framer-motion';
import { Remedy } from '../types';
import { MapPin, Info, AlertCircle } from 'lucide-react';

interface RemedyCardProps {
  remedy: Remedy;
  onClick: (remedy: Remedy) => void;
}

export const RemedyCard: React.FC<RemedyCardProps> = ({ remedy, onClick }) => {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      className="bg-white rounded-3xl p-6 shadow-sm border border-black/5 cursor-pointer flex flex-col h-full"
      onClick={() => onClick(remedy)}
    >
      <div className="flex gap-4 mb-4">
        <div className="w-20 h-28 rounded-full overflow-hidden shrink-0 border border-black/5 shadow-inner">
          <img 
            src={`https://picsum.photos/seed/${remedy.imageSeed}/200/300`} 
            alt={remedy.name}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="flex flex-col justify-between py-1">
          <div className="flex justify-between items-start">
            <span className="text-[10px] uppercase tracking-widest font-semibold text-brand-olive bg-brand-olive/10 px-2 py-1 rounded-full">
              {remedy.region}
            </span>
          </div>
          
          <h3 className="text-xl font-serif font-semibold leading-tight">
            {remedy.name}
          </h3>
          
          <p className="text-[11px] text-brand-ink/60 italic">
            {remedy.culturalOrigin}
          </p>
        </div>
      </div>
      
      <div className="flex flex-wrap gap-1 mt-auto">
        {remedy.symptoms.slice(0, 3).map((symptom) => (
          <span key={symptom} className="text-[11px] bg-brand-cream px-2 py-0.5 rounded-md border border-black/5">
            {symptom}
          </span>
        ))}
        {remedy.symptoms.length > 3 && (
          <span className="text-[11px] text-brand-ink/40 px-1">+{remedy.symptoms.length - 3} more</span>
        )}
      </div>
      
      {remedy.caution && (
        <div className="mt-4 flex items-center gap-2 text-[10px] text-red-600/70 font-medium">
          <AlertCircle className="w-3 h-3" />
          <span>Caution advised</span>
        </div>
      )}
    </motion.div>
  );
};
