import { GoogleGenAI } from "@google/genai";
import { Remedy } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function getAncestralAdvice(symptom: string, location?: string): Promise<string> {
  const model = "gemini-3-flash-preview";
  const prompt = `You are a wise traditional healer with knowledge of global home remedies. 
  A user is experiencing: "${symptom}". 
  ${location ? `They are currently in: ${location}.` : ""}
  
  Provide a brief, comforting piece of "Granny's advice" or a traditional remedy that might help, 
  explaining the cultural background. Keep it concise and warm. 
  Always include a disclaimer that this is not professional medical advice.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text || "I'm sorry, the ancestors are quiet today. Please consult a doctor.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The connection to ancestral wisdom was interrupted. Please try again later.";
  }
}

export async function explainRemedy(remedy: Remedy): Promise<string> {
  const model = "gemini-3-flash-preview";
  const prompt = `Explain the traditional and scientific context of this remedy:
  Name: ${remedy.name}
  Ingredients: ${remedy.ingredients.join(", ")}
  Origin: ${remedy.culturalOrigin}
  
  Explain why these ingredients are traditionally used and if there's any modern scientific understanding of their effectiveness. 
  Be objective but respectful of the tradition.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text || "No further explanation available.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Could not fetch explanation.";
  }
}
